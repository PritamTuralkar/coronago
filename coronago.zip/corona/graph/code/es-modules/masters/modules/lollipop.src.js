/**
 * @license Highcharts JS v8.2.2 (2020-10-22)
 * @module highcharts/modules/lollipop
 * @requires highcharts
 *
 * (c) 2009-2019 Sebastian Bochan, Rafal Sebestjanski
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../Series/LollipopSeries.js';
