<?php

$server='localhost';
$user='root';
$password='';
$db='coronadb';

$con=mysqli_connect($server,$user,$password,$db);

/*if($con){
    ?>
 <script type="text/javascript">alert("connection succesful");</script>

    <?php
}else{
?>
<script type="text/javascript">alert("connection fail");</script>
<?php
}





db 000webhost info------  username: pritam    password:  Kw]f7V~~K!5dz2p%






*/

?>